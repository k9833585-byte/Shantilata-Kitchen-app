# Shantilata Kitchen Android WebView wrapper

This Android Studio project opens the existing Shantilata Kitchen Apps Script web app in a full-screen WebView. It uses the supplied URL and keeps the backend online in Google Sheets; it is not an offline app.

## Build APK
1. Install Android Studio on a Windows, macOS, or Linux computer.
2. Open this project folder in Android Studio and allow Gradle sync.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)** for a test APK.
4. Android Studio shows the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.
5. For distribution, use **Build > Generate Signed Bundle / APK > APK** and create/keep a private signing key securely.

The APK must be signed for installation. Keep the signing key and password private and backed up; they are needed for future app updates.

## Notes
- Internet connection is required.
- The app loads the deployed web app; changes to the Apps Script deployment appear without rebuilding this wrapper.
- The app does not contain Owner or Employee PINs.
- The supplied web app is configured for public URL access with PIN login. Anyone who obtains the URL can reach its login screen, so keep the PINs private.
